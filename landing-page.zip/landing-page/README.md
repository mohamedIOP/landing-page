# what is this ?
this is the landing-project readme so I will explain in this file what iam gonna do in the project
# what is the languages of this project ? 
In This project i used these three languages:
1-HTML 
2-CSS
3-JavaScript
# what is the parts of the web page ?
i have some parts in the page:
first part is the navgation bar
second part is the header or the name of the project
third part is the sections of the project
fourth part is the footer
# what will i do in this project ?
make some changes with dom and java script 
