/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Define Global Variables
 * 
*/
// the var below is defined in global scope and it takes the navigator bar elements and store it in var called navigation 
const navigation = document.getElementById("navbar__list");
// this is also defined in global scope but it takes all the elements with the tag section and store it in sections variable
const sections = document.querySelectorAll("section");
/**
 * End Global Variables
 * Start Helper Functions
 * 
*/

/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/
// build the nav
function navigator (){
    for(const section of sections){
        const sectionId = section.id;
        const sectionName = section.dataset.nav;
        const liEl = document.createElement("li");
        const anchor = document.createElement("a");
        anchor.classList.add("menu__link");
        anchor.setAttribute("href","#"+sectionId);
        anchor.innerHTML = sectionName;
        navigation.appendChild(liEl);
        liEl.appendChild(anchor);
    }
}
navigator();
// Add class 'active' to section when near top of viewport
function position (section){
    return section.getBoundingClientRect().top;
}
function addActive(choice,section){
    if(choice){
        section.classList.add("your-active-class");
    }
}
function removeActive(section){
    section.classList.remove("your-active-class");
}
function loopOver(){
    for(const section of sections){
        const thePosition = position(section);
        function viewport(){
            if(thePosition < 180 && thePosition >= -150){
                return true;
            }
            else{
                return false;
            };
        }
        removeActive(section);
        addActive(viewport(),section);
    }
}
window.addEventListener("scroll",loopOver);

// Scroll to anchor ID using scrollTO event

/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu 

// Scroll to section on link click

// Set sections as active


